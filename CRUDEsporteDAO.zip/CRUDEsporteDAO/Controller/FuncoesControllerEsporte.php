<?php
class FuncoesControllerEsporte {
    
    public function inserirEsporte($codigo, $nome, $descricao, $modalidade) {
        include_once '../Model/EsporteDAO.php';
        $esporteDao = new EsporteDAO();
        $mensagem = $esporteDao->inserirEsporteDAO($codigo, $nome, $descricao, $modalidade);
        return $mensagem;
    }
    
    public function pesquisaEsportes() {
        include_once '../Model/EsporteDAO.php';
        $esporteDao = new EsporteDAO();
        $linhaNova = $esporteDao->pesquisaEsportesDao();
        return $linhaNova;
    }
    public function pesquisaModalidades() {
        include_once '../Model/EsporteDAO.php';
        $esporteDao = new EsporteDAO();
        $linhaNova = $esporteDao->pesquisaModalidadesDao();
        return $linhaNova;
    }
    
    public function editarEsporte($codigo, $nome, $descricao, $modalidade) {
        include_once '../Model/EsporteDAO.php';
        $esporteDao = new EsporteDAO();
        $mensagem = $esporteDao->editarEsporteDao($codigo, $nome, $descricao, $modalidade);
        return $mensagem;
    }
    
    public function excluiEsporte($codigo) {
        include_once '../Model/EsporteDAO.php';
        $esporteDao = new EsporteDAO();
        $mensagem = $esporteDao->excluiEsporteDao($codigo);
        return $mensagem;
    }
    
    public function proximoCodigoEsporte(){
        include_once '../Model/EsporteDAO.php';
        $esporteDao = new EsporteDAO();
        $mensagem = $esporteDao->proximoCodigoEsporteDao();
        return $mensagem;
    }
}
