<?php
class Esporte {
    private $codigo;
    private $nome;
    private $descricao;
    private $modalidade;
    
    public function setCodigo($codigo){
        $this->codigo = $codigo;
    }
    public function getCodigo(){
        return $this->codigo;
    }
    
    public function setNome($nome){
        $this->nome = $nome;
    }
    public function getNome(){
        return $this->nome;
    }
    
    public function setDescricao($descricao){
        $this->descricao = $descricao;
    }
    public function getDescricao(){
        return $this->descricao;
    }
    
    public function setModalidade($modalidade){
        $this->modalidade = $modalidade;
    }
    public function getModalidade(){
        return $this->modalidade;
    }
}
