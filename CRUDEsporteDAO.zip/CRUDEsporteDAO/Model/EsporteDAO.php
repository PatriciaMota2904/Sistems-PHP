<?php
include_once 'Esporte.php';
class EsporteDAO {
    public function inserirEsporteDAO($codigo, $nome, $descricao, $modalidade) {
        $esporte = new Esporte();
        $esporte->setCodigo($codigo);
        $esporte->setNome($nome);
        $esporte->setDescricao($descricao);
        $esporte->setModalidade($modalidade);
        include_once '../Model/ConectaBd.php';
        $conectaBd = new ConectaBd();
        $mensagem = "<p class='msgResp bg-success text-center'>Dados inseridos com sucesso.</p>";
        if($conectaBd->_construct() == true) {
            $sql = "insert into esporte values ('".$esporte->getCodigo()."', '".$esporte->getNome()."', '".$esporte->getDescricao()."', '".$esporte->getModalidade()."')";
            $query = mysqli_query($conectaBd->db, $sql) or die(mysqli_error($conectaBd->db));
            //$linha = mysqli_fetch_array($query, MYSQLI_ASSOC);
        }else{
            $mensagem = "<p class='msgResp bg-warning text-center'>Problemas na conexão com o banco de dados.</p>";
        }
        $conectaBd->_destruct();
        return $mensagem;
    }
    
    public function pesquisaEsportesDao() {
        include_once 'ConectaBd.php';
        $conectaBd = new ConectaBd();
        $linhaNova = array();
        if($conectaBd->_construct() === true) {
            $sql = "select * from esporte";
            $query = mysqli_query($conectaBd->db, $sql) or die(mysqli_error($conectaBd->db));
            while($linha = mysqli_fetch_array($query)) {
                array_push($linhaNova, $linha);
            }
            $conectaBd->_destruct();
        }
        return $linhaNova;
    }
    
    public function pesquisaModalidadesDao() {
        include_once 'ConectaBd.php';
        $conectaBd = new ConectaBd();
        $linhaNova = array();
        if($conectaBd->_construct() === true) {
            $sql = "select * from modalidades";
            $query = mysqli_query($conectaBd->db, $sql) or die(mysqli_error($conectaBd->db));
            while($linha = mysqli_fetch_array($query)) {
                array_push($linhaNova, $linha);
            }
            $conectaBd->_destruct();
        }
        return $linhaNova;
    }
    
    public function editarEsporteDao($codigo, $nome, $descricao, $modalidade) {
        $esporte = new Esporte();
        $esporte->setCodigo($codigo);
        $esporte->setNome($nome);
        $esporte->setDescricao($descricao);
        $esporte->setModalidade($modalidade);
        include_once '../Model/ConectaBd.php';
        $conectaBd = new ConectaBd();
        $mensagem = "<p class='msgResp bg-success text-center'>Dados alterados com sucesso.</p>";
        if($conectaBd->_construct() === true) {
            $sql = "update esporte set nome = '".$esporte->getNome()."', descricao = '".$esporte->getDescricao()."',"
                    . "FKModalidade = '".$esporte->getModalidade()."' where codigo = '".$esporte->getCodigo()."'";
            mysqli_query($conectaBd->db, $sql) or die(mysqli_error($conectaBd->db));
            //$linha = mysqli_fetch_array($query, MYSQLI_ASSOC);
        }else{
            $mensagem = "<p class='msgResp bg-warning text-center'>Problemas na conexão com o banco de dados.</p>";
        }
        $conectaBd->_destruct();
        return $mensagem;
    }
    
    public function excluiEsporteDao($codigo) {
        $esporte = new Esporte();
        $esporte->setCodigo($codigo);
        include_once 'ConectaBd.php';
        $conectaBd = new ConectaBd();
        $mensagem = "<p class='msgResp bg-success text-center'>Dados excluídos com sucesso.</p>";
        if($conectaBd->_construct() === true) {
            $sql = "delete from esporte where codigo = '".$esporte->getCodigo()."'";
            mysqli_query($conectaBd->db, $sql) or die(mysqli_error($conectaBd->db));
            //$linha = mysqli_fetch_array($query, MYSQLI_ASSOC);
        }else{
            $mensagem = "<p class='msgResp bg-warning text-center'>Problemas na conexão com o banco de dados.</p>";
        }
        $conectaBd->_destruct();
        return $mensagem;
    }
    
    public function proximoCodigoEsporteDao(){
        include_once 'ConectaBd.php';
        $conectaBd = new ConectaBd();
        $codigo = 0;
        if($conectaBd->_construct() === true) {
            $sql = "select codigo from esporte order by codigo asc";
            $query = mysqli_query($conectaBd->db, $sql) or die(mysqli_error($conectaBd->db));
            $linha = mysqli_fetch_array($query, MYSQLI_ASSOC);
            if($linha){
                $n = 1;
                do{
                    if($n < $linha['codigo']){
                        $codigo = $n;
                        break;
                    }else{
                        $codigo = $n + 1;
                    }
                    $n++;
                }while($linha = mysqli_fetch_array($query, MYSQLI_ASSOC));
            }else{
                $codigo = 1;
            }
        }
        $conectaBd->_destruct();
        return $codigo;
    }
}
