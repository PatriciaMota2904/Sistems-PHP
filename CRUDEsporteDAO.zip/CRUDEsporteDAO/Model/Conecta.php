<?php
$db = mysqli_connect("localhost", "root", "senac", "dbesporte") or die("Servidor Fora do ar.");
mysqli_select_db($db, "dbesporte") or die("Banco fora do ar.");

