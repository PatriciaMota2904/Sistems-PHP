// JavaScript Document
function entrada(){
	document.logaAvisos.login.focus();	
}
