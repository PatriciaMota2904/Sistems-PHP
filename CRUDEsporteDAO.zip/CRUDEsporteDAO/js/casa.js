function limpar(){
	document.getElementById('nome').value = "";
	document.getElementById('email').value = "";
	document.getElementById('senha').value = "";
	document.getElementById('senha2').value = "";
}