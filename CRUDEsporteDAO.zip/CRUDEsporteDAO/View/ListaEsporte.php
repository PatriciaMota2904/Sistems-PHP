<?php
include_once '../Controller/FuncoesControllerEsporte.php';
$fce = new FuncoesControllerEsporte();
$linhas = $fce->pesquisaEsportes();
$linhasModalidades = $fce->pesquisaModalidades();
?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Lista Esportes</title>
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <link href="../css/bootstrap.css" rel="stylesheet">
        <link href="../css/estilo.css" rel="stylesheet">
        <link rel="stylesheet" href="../css/redmond/jquery-ui-1.10.1.custom.css" />
        <link href="../css/bootstrap-grid.css" rel="stylesheet">
    </head>
    <body>
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="container-fluid">
                <div class="navbar-header">
                    <!-- data-toggle="collapse" data-target="#elementoCollapse" permitem criar um botão que esconde e disponibiliza o conteúdo do formulário da div que tem o id="elementoCollapse" --> 
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#elementoCollapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a href="#" class="navbar-brand">Empresa Teste</a>
                </div>
                <div class="collapse navbar-collapse" id="elementoCollapse">
                    <button type="button" class="btn btn-default navbar-btn">Link</button>
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="#">Item 1</a></li>
                        <li><a href="#">Item 1</a></li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Clientes <span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="CadastroEsporte.php" >Cadastro de Esporte</a></li>
                                <li><a href="ListaEsporte.php" >Listagem de Esporte</a></li>
                                <li><a href="#" >Sublink</a></li>
                                <li class="divider"></li>
                                <li><a href="#" >Sublink</a></li>
                            </ul>
                        </li>
                    </ul>
                    <p class="navbar-text navbar-right">
                        Olá, <strong>Aluno!</strong>
                    </p>
                    <form class="navbar-form navbar-right" >
                        <div class="form-group">
                            <input class="form-control" placeholder="Busca">
                            <input type="submit" value="Buscar" class="btn btn-primary">
                        </div>
                    </form>
                </div>
            </div>
        </nav>   
        <div class="container">
            <div class="row">               
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                                <?php
                                //codigo para efetivar a Alteração dos dados do cliente
                                if(isset($_POST['confirmarAlteracao'])) {
                                    $msg = $fce->editarEsporte($_POST['codigo'], $_POST['nome'], 
                                            $_POST['descricao'], $_POST['modalidade']);
                                    //Alterando dados no BD
                                    echo $msg;
                                    echo "<META HTTP-EQUIV='REFRESH' CONTENT=\"1;
                                        URL='ListaEsporte.php'\">";
                                }
                                //codigo para efetivar a exclusão dos dados do cliente
                                if (isset($_POST['confirmarExclusao'])) {
                                    $codigo = $_POST['codigo'];
                                    //excluindo no BD
                                    $msg = $fce->excluiEsporte($_POST['codigo']);
                                    echo $msg;
                                    echo "<META HTTP-EQUIV='REFRESH' CONTENT=\"1;
                                        URL='ListaEsporte.php'\">";
                                }
                                ?>
                            <div class="panel panel-info">
                                <div class="panel-heading">
                                    <h3 class="text-primary">Lista de Esportes</h3>
                                </div>
                                <div class="panel-body">
                                    <table class="table table-striped table-condensed table-hover">                
                                        <thead>
                                            <tr>	
                                                <th>Código</th>
                                                <th>Esporte</th>
                                                <th>Descição</th>
                                                <th>Modalidade</th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                        </thead>                          
                                        <tbody>
                                            <?php
                                            if ($linhas) {
                                                $a = 0;
                                                foreach ($linhas as $linha) {
                                                    $a++;
                                                    ?>
                                                    <tr>
                                                        <td><?php echo $linha['codigo']; ?></td>
                                                        <td><?php echo $linha['nome']; ?></td>
                                                        <td><?php echo $linha['descricao']; ?></td>
                                                        <td><?php 
                                                                    foreach ($linhasModalidades as $linhaModalidade) {
                                                                        if($linha['FKModalidade']===$linhaModalidade['idmodalidades']){
                                                                            echo $linhaModalidade['modalidade'];
                                                                        }
                                                                    }
                                                            ?></td>
                                                        <td><button type="button" class="btn btn-default" data-toggle="modal" data-target="#modal_ed<?php echo $a; ?>"><img src="../img/edita.ico" width="16"></button></td>
                                                        <td><button type="button" class="btn btn-default" data-toggle="modal" data-target="#modal_exc<?php echo $a; ?>"><img src="../img/deleta.ico" width="16"></button></td>
                                                    </tr>
                                                    <!-- janela modal Editar Esporte -->
                                                    <div class="modal fade" id="modal_ed<?php echo $a; ?>" role="dialog" tabindex="-1" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <button type="button" class="close" data-dismiss="modal">
                                                                    <span aria-hidden="true">&times;</span>
                                                                    <span class="sr-only">Fechar a tela modal</span>
                                                                </button>
                                                                <h4 class="modal-title">Dados para Edição</h4>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form method="post">
                                                                    <div class="form-group">
                                                                        <label for="nome">Esporte:</label>
                                                                        <input type="text" class="form-control" name="nome" value="<?php echo $linha['nome'];?>" required="required"/>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="nome">Descrição:</label>
                                                                        <input type="text" class="form-control" name="descricao" value="<?php echo $linha['descricao'];?>" required="required"/>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="nome">Modalidade:</label>
                                                                        <select class="form-control" name="modalidade">
                                                                            <option>-</option>
                                                                            <?php 
                                                                                foreach($linhasModalidades as $linhaModalidade) {          
                                                                            ?>
                                                                            <option value="<?php echo $linhaModalidade['idmodalidades'];?>" 
                                                                            <?php if($linha['FKModalidade']===$linhaModalidade['idmodalidades']){ 
                                                                            echo "selected='selected'"; } ?>>
                                                                                <?php echo $linhaModalidade['modalidade'];?>
                                                                            </option>
                                                                            <?php 
                                                                                }          
                                                                            ?>
                                                                        </select>
                                                                    </div>

                                                            </div>
                                                            <div class="modal-footer">
                                                                <input type="hidden" name="codigo" value="<?php echo $linha['codigo']; ?>">
                                                                <input type="submit" name="confirmarAlteracao" class="btn btn-default" value=" Enviar ">
                                                                <input type="submit" class="btn btn-danger" value="Cancelar">
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div> 
                                                <!-- // janela modal -->
                                                <!-- janela modal Excluir Esporte -->
                                                <div class="modal fade" id="modal_exc<?php echo $a; ?>" role="dialog" tabindex="-1" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <button type="button" class="close" data-dismiss="modal">
                                                                    <span aria-hidden="true">&times;</span>
                                                                    <span class="sr-only">Fechar a tela modal</span>
                                                                </button>
                                                                <h4 class="modal-title">Dados para Exclusão</h4>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p>Deseja excluir os dados de <?php echo $linha['nome']; ?></p>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <form method="post">
                                                                    <input type="hidden" name="codigo" value="<?php echo $linha['codigo']; ?>">
                                                                    <input type="submit" name="confirmarExclusao" class="btn btn-default" value="Excluir">
                                                                    <input type="submit" class="btn btn-danger" value="Cancelar">
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- // janela modal -->
                                            <?php
                                        }
                                    }
                                    ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <script src="../js/jquery-3.1.1.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/main.js"></script>
  </body>
</html>