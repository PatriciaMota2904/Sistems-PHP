<?php
include_once '../Controller/FuncoesControllerEsporte.php';
$fce = new FuncoesControllerEsporte();
$linhasModalidades = $fce->pesquisaModalidades();
$id = $fce->proximoCodigoEsporte();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>PHP interação com BD</title>
        <link rel="stylesheet" href="../css/bootstrap-grid.css">
        <link rel="stylesheet" href="../css/bootstrap-grid.min.css">
        <link rel="stylesheet" href="../css/bootstrap-reboot.css">
        <link rel="stylesheet" href="../css/bootstrap-reboot.min.css">
        <link rel="stylesheet" href="../css/bootstrap-theme.css">
        <link rel="stylesheet" href="../css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="../css/bootstrap.css">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../css/estilo.css">
        
    </head>
    <body>
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="container-fluid">
                <div class="navbar-header">
                    <!-- data-toggle="collapse" data-target="#elementoCollapse" permitem criar um botão que esconde e disponibiliza o conteúdo do formulário da div que tem o id="elementoCollapse" --> 
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#elementoCollapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a href="#" class="navbar-brand">Empresa Teste</a>
                </div>
                <div class="collapse navbar-collapse" id="elementoCollapse">
                    <button type="button" class="btn btn-default navbar-btn">Link</button>
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="#">Item 1</a></li>
                        <li><a href="#">Item 1</a></li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Clientes <span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="CadastroCliente.php" >Cadastro de Esportes</a></li>
                                <li><a href="#" >Sublink</a></li>
                                <li class="divider"></li>
                                <li><a href="#" >Sublink</a></li>
                            </ul>
                        </li>
                    </ul>
                    <p class="navbar-text navbar-right">Olá, <strong>Aluno!</strong></p>
                    <form class="navbar-form navbar-right" >
                        <div class="form-group">
                            <input class="form-control" placeholder="Busca">
                            <input type="submit" value="Buscar" class="btn btn-primary">
                        </div>
                    </form>
                </div>
            </div>
        </nav>   
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <h3>Cadastro de Esporte (Padrão MVC)</h3>
                    <?php
                    if(isset($_POST['confirmarEnvio'])) { 
                        include_once '../Controller/FuncoesControllerEsporte.php';
                        $fce = new FuncoesControllerEsporte();
                        $msg = $fce->inserirEsporte($_POST['codigo'], $_POST['nome'], $_POST['descricao'], $_POST['modalidade']);
                        echo $msg;
                        echo "<META HTTP-EQUIV='REFRESH' CONTENT=\"1;
                               URL='CadastroEsporte.php'\">";
                    }
                    ?>
                    <form method="post">
                        <div class="form-group">
                            <label for="nome">Código: </label>
                            <label for="nome"><?php echo $id;?></label>
                            <input type="hidden" class="form-control" name="codigo" value="<?php echo $id;?>"/>
                        </div>
                        <div class="form-group">
                            <label for="nome">Nome completo:</label>
                            <input type="text" class="form-control" name="nome" required="required"/>
                        </div>
                        <div class="form-group">
                            <label for="nome">Descrição:</label>
                            <textarea class="form-control" name="descricao" required="required"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="nome">Modalidade:</label>
                            <select class="form-control" name="modalidade">
                                <option>-</option>
                                <?php 
                                    foreach($linhasModalidades as $linhaModalidade) {          
                                ?>
                                <option value="<?php echo $linhaModalidade['idmodalidades'];?>">
                                    <?php echo $linhaModalidade['modalidade'];?>
                                </option>
                                <?php 
                                    }          
                                ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <input type="submit" value="Enviar" name="confirmarEnvio" /> 
                            <input type="reset" value="Limpar" />
                        </div>
                    </form>
                </div>
            </div>
        </div>        
        <script src="../js/jquery-3.1.1.min.js"></script>
        <script src="../js/bootstrap.js"></script>
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/bootstrap.bundle.js"></script>
        <script src="../js/bootstrap.bundle.min.js"></script>
        <script src="../js/casa.js"></script>
        <script src="../js/main.js"></script>
    </body>
</html>



