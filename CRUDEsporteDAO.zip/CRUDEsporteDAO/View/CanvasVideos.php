<?php
include("Conecta.php");
$sql = "select codigo from esporte";
$query = mysqli_query($db, $sql) or die(mysqli_error($db));
$linha = mysqli_fetch_array($query, MYSQLI_ASSOC);
$numLinha = mysqli_num_rows($query);
$codigo = 0;
if($linha){
    $n = 0;
    do{
        $n++;
        if($n < $linha['codigo']){
            $codigo = $n;
            break;
        }else{
            $codigo = $n + 1;
        }
    }while($linha = mysqli_fetch_array($query, MYSQLI_ASSOC));
}else{
    $codigo = 1;
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>PHP interação com BD</title>
        <canvas id=c></canvas> <video id=v controls loop> 
            <source src=video.webm type=video/webm> 
            <source src=video.ogg type=video/ogg> 
            <source src=video.mp4 type=video/mp4> 
        </video>
        <link rel="stylesheet" href="css/bootstrap-grid.css">
        <link rel="stylesheet" href="css/bootstrap-grid.min.css">
        <link rel="stylesheet" href="css/bootstrap-reboot.css">
        <link rel="stylesheet" href="css/bootstrap-reboot.min.css">
        <link rel="stylesheet" href="css/bootstrap-theme.css">
        <link rel="stylesheet" href="css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/estilo.css">
        <style> 
            body { background: black; } 
            #c { position: absolute; top: 0; bottom: 0; left: 0; right: 0; width: 100%; height: 100%; } 
            #v { position: absolute; top: 50%; left: 50%; margin: -180px 0 0 -240px; } 
        </style>
    </head>
    <body>
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="container-fluid">
                <div class="navbar-header">
                    <!-- data-toggle="collapse" data-target="#elementoCollapse" permitem criar um botão que esconde e disponibiliza o conteúdo do formulário da div que tem o id="elementoCollapse" --> 
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#elementoCollapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a href="#" class="navbar-brand">Empresa Teste</a>
                </div>
                <div class="collapse navbar-collapse" id="elementoCollapse">
                    <button type="button" class="btn btn-default navbar-btn">Link</button>
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="#">Item 1</a></li>
                        <li><a href="#">Item 1</a></li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Clientes <span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="CadastroCliente.php" >Cadastro de Esportes</a></li>
                                <li><a href="#" >Sublink</a></li>
                                <li class="divider"></li>
                                <li><a href="#" >Sublink</a></li>
                            </ul>
                        </li>
                    </ul>
                    <p class="navbar-text navbar-right">Olá, <strong>Aluno!</strong></p>
                    <form class="navbar-form navbar-right" >
                        <div class="form-group">
                            <input class="form-control" placeholder="Busca">
                            <input type="submit" value="Buscar" class="btn btn-primary">
                        </div>
                    </form>
                </div>
            </div>
        </nav>   
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <h3>Vídeo e Canvas</h3>
                    
                </div>
            </div>
        </div>
        

        <script src="js/jquery-3.1.1.min.js"></script>
        <script src="js/bootstrap.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/bootstrap.bundle.js"></script>
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/casa.js"></script>
        <script src="js/main.js"></script>
        <script> document.addEventListener('DOMContentLoaded', function(){ var v = document.getElementById('v'); var canvas = document.getElementById('c'); var context = canvas.getContext('2d'); var cw = Math.floor(canvas.clientWidth / 100); var ch = Math.floor(canvas.clientHeight / 100); canvas.width = cw; canvas.height = ch; v.addEventListener('play', function(){ draw(this,context,cw,ch); },false); },false); function draw(v,c,w,h) { if(v.paused || v.ended) return false; c.drawImage(v,0,0,w,h); setTimeout(draw,20,v,c,w,h); } </script>
    </body>
</html>



